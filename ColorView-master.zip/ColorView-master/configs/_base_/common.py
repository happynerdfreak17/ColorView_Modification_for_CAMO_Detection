has_test = True
base_seed = 0
deterministic = True

log_interval = dict(  # >0 will be logged
    txt=20,
    tensorboard=0,
)
load_from = ""
resume_from = ""
model_name = ""
experiment_tag = ""
