# -*- coding: utf-8 -*-

from .MultiView_cod import MFFN_COD_TestDataset, MFFN_COD_TrainDataset
from .MultiView_rgbshuffle import MFFN_rgbshuffle_TestDataset, MFFN_rgbshuffle_TrainDataset
from .MultiView_jittershuffle import MFFN_jittershuffle_TestDataset, MFFN_jittershuffle_TrainDataset
from .MultiView_huesaturation import MFFN_huesaturation_TestDataset, MFFN_huesaturation_TrainDataset
